package com.you.chargestatus;

import android.content.Context;
import android.graphics.Color;
import android.os.Handler;
import android.os.HandlerThread;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.FileReader;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    private static final String VOLTAGE_PATH = "/sys/class/power_supply/battery/voltage_now";
    private static final String CURRENT_PATH = "/sys/class/power_supply/battery/current_now";
    private static final String STATUS_PATH  = "/sys/class/power_supply/battery/status";
    private static final int    REFRESH_MS   = 2000;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) {
        if (!lpparam.packageName.equals("com.android.systemui")) return;

        XposedBridge.log("ChargeStatus: hooked into SystemUI");

        // Hook the Clock view on the LEFT side of the status bar.
        // On AOSP / near-stock Motorola Android 12-13 the clock class is:
        //   com.android.systemui.statusbar.policy.Clock
        XposedHelpers.findAndHookMethod(
            "com.android.systemui.statusbar.policy.Clock",
            lpparam.classLoader,
            "onFinishInflate",
            new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        View clockView = (View) param.thisObject;
                        ViewGroup parent = (ViewGroup) clockView.getParent();
                        if (parent == null) return;

                        // Guard against duplicate injection
                        if (parent.findViewWithTag("charge_watt_label") != null) return;

                        Context ctx = clockView.getContext();

                        // Build the wattage label
                        TextView wattLabel = new TextView(ctx);
                        wattLabel.setTag("charge_watt_label");
                        wattLabel.setTextSize(12f);   // same visual weight as clock
                        wattLabel.setTextColor(Color.WHITE);
                        wattLabel.setGravity(Gravity.CENTER_VERTICAL);
                        wattLabel.setPadding(8, 0, 0, 0); // small gap after clock
                        wattLabel.setText("");  // blank until first read

                        // Insert our label immediately AFTER the clock
                        int clockIndex = parent.indexOfChild(clockView);
                        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        );
                        lp.gravity = Gravity.CENTER_VERTICAL;
                        parent.addView(wattLabel, clockIndex + 1, lp);

                        XposedBridge.log("ChargeStatus: label injected after clock");

                        // Background reader thread — never blocks the UI
                        HandlerThread bgThread = new HandlerThread("ChargeWattReader");
                        bgThread.start();
                        Handler bgHandler = new Handler(bgThread.getLooper());
                        Handler uiHandler = new Handler(ctx.getMainLooper());

                        bgHandler.post(new Runnable() {
                            @Override
                            public void run() {
                                String label = "";
                                try {
                                    long voltageUv = readLong(VOLTAGE_PATH);
                                    long currentUa = readLong(CURRENT_PATH);
                                    String status  = readString(STATUS_PATH);

                                    long vMv = voltageUv / 1000;
                                    long iMa = Math.abs(currentUa / 1000);
                                    long pMw = vMv * iMa / 1000;

                                    long wInt = pMw / 1000;
                                    long wDec = (pMw % 1000) / 10;

                                    boolean isCharging = currentUa > 0
                                        && status != null
                                        && status.contains("Charging");

                                    // Show ⚡X.XXW while charging, blank otherwise
                                    label = isCharging
                                        ? String.format("⚡%d.%02dW", wInt, wDec)
                                        : "";

                                } catch (Exception e) {
                                    XposedBridge.log("ChargeStatus: " + e.getMessage());
                                }

                                final String finalLabel = label;
                                uiHandler.post(() -> wattLabel.setText(finalLabel));
                                bgHandler.postDelayed(this, REFRESH_MS);
                            }
                        });

                    } catch (Exception e) {
                        XposedBridge.log("ChargeStatus hook error: " + e.getMessage());
                    }
                }
            }
        );
    }

    private long readLong(String path) throws Exception {
        return Long.parseLong(readString(path).trim());
    }

    private String readString(String path) throws Exception {
        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line = br.readLine();
            return line != null ? line.trim() : "";
        }
    }
}
